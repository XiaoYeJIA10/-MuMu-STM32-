.\objects\petaction.o: HardWare\PetAction.c
.\objects\petaction.o: HardWare\PetAction.h
