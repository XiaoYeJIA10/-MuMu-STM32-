/*
 * 本代码由 硬件小烨JIA 编写，参考江协科技的STM32外设代码，用于控制 MuMu 机器人
 * MuMu 主程序
 * 当前功能：
 * 1. 上电后随机播放 MuMu 的 5 种眼睛表情。
 * 2. 收到 0x31（立正）命令后，左右手同时向下转动。
 * 3. 收到 0x32（打招呼）命令后，右手摇手 2 秒。
 * 4. 收到 0x33（上才艺）命令后，双手快速摇摆 4 秒。
 * 5. 收到 0x34（稍息）命令后，双手抬起并保持 2 秒。
 * 6. 所有动作完成后回到初始姿态，并恢复随机表情播放。
 *
 * 舵机接线：
 * PA2 -> 左手
 * PA3 -> 右手
 * 
 * 
 */

#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "BlueTooth.h"
#include "Servo.h"
#include "Face_Config.h"

/* MuMu 语音指令。 */
#define MUMU_CMD_UPRIGHT            0x31
#define MUMU_CMD_GREET              0x32
#define MUMU_CMD_TALENT             0x33
#define MUMU_CMD_REST               0x34

/* 上电时左右手的独立初始角度，可根据实际安装方向分别修改。 */
#define MUMU_LEFT_ARM_INIT_ANGLE    180.0f
#define MUMU_RIGHT_ARM_INIT_ANGLE   180.0f

/*
 * 立正时左右手向下的独立角度。
 * 两个参数的取值范围均为 0.0f 到 180.0f。
 */
#define MUMU_LEFT_ARM_DOWN_ANGLE    0.0f
#define MUMU_RIGHT_ARM_DOWN_ANGLE   0.0f

/* 打招呼动作：右手在初始角度和 90 度之间来回摆动。 */
#define MUMU_GREET_LOW_ANGLE        90.0f
#define MUMU_GREET_HALF_PERIOD_MS   500
#define MUMU_GREET_TOTAL_MS         2000

/* 上才艺动作：双手在 0 度和 180 度之间快速摆动。 */
#define MUMU_TALENT_HIGH_ANGLE      180.0f
#define MUMU_TALENT_LOW_ANGLE       0.0f
#define MUMU_TALENT_HALF_PERIOD_MS  250
#define MUMU_TALENT_TOTAL_MS        4000

/* 稍息动作：双手抬到约 120 度并保持 2 秒。 */
#define MUMU_REST_HOLD_ANGLE        120.0f
#define MUMU_REST_HOLD_MS           2000

/* 让左右手同时转动到立正时的向外角度。 */
static void MuMu_MoveArmsDown(void)
{
    Servo_LeftArm(MUMU_LEFT_ARM_DOWN_ANGLE);
    Servo_RightArm(MUMU_RIGHT_ARM_DOWN_ANGLE);
}

int main(void)
{
    uint8_t Command;

    Servo_Init();
    OLED_Init();
    BlueTooth_Init();
    MuMuFace_Init();

    /* 设置上电初始姿态，左右手分别使用独立参数。 */
    Servo_SetInitialAngles(MUMU_LEFT_ARM_INIT_ANGLE,
                           MUMU_RIGHT_ARM_INIT_ANGLE);
    Servo_ReturnToInit();

    while (1)
    {
        Command = BlueTooth_GetCommand();

        if (Command == MUMU_CMD_UPRIGHT)
        {
            MuMu_MoveArmsDown();
            MuMuFace_ShowHappyOnce();
            Servo_ReturnToInit();
            continue;
        }
        else if (Command == MUMU_CMD_GREET)
        {
            Servo_StartRightWave(MUMU_RIGHT_ARM_INIT_ANGLE,
                                 MUMU_GREET_LOW_ANGLE,
                                 MUMU_GREET_HALF_PERIOD_MS,
                                 MUMU_GREET_TOTAL_MS);
            MuMuFace_ShowSurprisedOnce();
            Servo_ReturnToInit();
            continue;
        }
        else if (Command == MUMU_CMD_TALENT)
        {
            Servo_StartBothSwing(MUMU_TALENT_HIGH_ANGLE,
                                 MUMU_TALENT_LOW_ANGLE,
                                 MUMU_TALENT_HALF_PERIOD_MS,
                                 MUMU_TALENT_TOTAL_MS);
            MuMuFace_ShowLookAroundOnce();

            /* 如果中途收到新指令，不再播放后半段无聊表情。 */
            if (!BlueTooth_HasCommand())
            {
                MuMuFace_ShowBoredOnce();
            }

            Servo_ReturnToInit();
            continue;
        }
        else if (Command == MUMU_CMD_REST)
        {
            Servo_StartBothHold(MUMU_REST_HOLD_ANGLE,
                                MUMU_REST_HOLD_MS);
            MuMuFace_ShowAngryOnce();
            Servo_ReturnToInit();
            continue;
        }

        /*
         * 没有收到新指令时，继续随机播放表情。
         */
        MuMuFace_PlayRandomEmotion();
    }
}
