#include "stm32f10x.h"
#include "PWM.h"
#include "Servo.h"

#define SERVO_ACTION_NONE           0
#define SERVO_ACTION_RIGHT_WAVE     1
#define SERVO_ACTION_BOTH_SWING     2
#define SERVO_ACTION_BOTH_HOLD      3

static volatile uint8_t MuMu_ServoAction = SERVO_ACTION_NONE;
static volatile uint16_t MuMu_ServoElapsedMs = 0;
static volatile uint16_t MuMu_MotionHighAngle = 180;
static volatile uint16_t MuMu_MotionLowAngle = 0;
static volatile uint16_t MuMu_MotionHalfPeriodMs = 250;
static volatile uint16_t MuMu_MotionTotalMs = 0;
static volatile uint16_t MuMu_InitialLeftAngle = 180;
static volatile uint16_t MuMu_InitialRightAngle = 180;

void Servo_Init(void)
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    PWM_Init();

    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);

    TIM_InternalClockConfig(TIM3);

    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_Period = 200 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 7200 - 1;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseInitStructure);

    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 3;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM3, ENABLE);
}

void Servo_SetInitialAngles(float LeftAngle, float RightAngle)
{
    MuMu_InitialLeftAngle = (uint16_t)LeftAngle;
    MuMu_InitialRightAngle = (uint16_t)RightAngle;
}

/* PA2：左手舵机。 */
void Servo_LeftArm(float Angle)
{
    PWM_SetCompare3((uint16_t)(Angle / 180.0f * 2000.0f + 500.0f));
}

/* PA3：右手舵机。与左手使用相同的角度映射，使镜像安装的双手反向转动。 */
void Servo_RightArm(float Angle)
{
    PWM_SetCompare4((uint16_t)(Angle / 180.0f * 2000.0f + 500.0f));
}

void Servo_ReturnToInit(void)
{
    __disable_irq();
    MuMu_ServoAction = SERVO_ACTION_NONE;
    MuMu_ServoElapsedMs = 0;
    __enable_irq();

    Servo_LeftArm((float)MuMu_InitialLeftAngle);
    Servo_RightArm((float)MuMu_InitialRightAngle);
}

void Servo_StartRightWave(float HighAngle, float LowAngle,
                          uint16_t HalfPeriodMs, uint16_t TotalMs)
{
    if (HalfPeriodMs == 0)
    {
        HalfPeriodMs = 1;
    }

    __disable_irq();
    MuMu_MotionHighAngle = (uint16_t)HighAngle;
    MuMu_MotionLowAngle = (uint16_t)LowAngle;
    MuMu_MotionHalfPeriodMs = HalfPeriodMs;
    MuMu_MotionTotalMs = TotalMs;
    MuMu_ServoElapsedMs = 0;
    MuMu_ServoAction = SERVO_ACTION_RIGHT_WAVE;
    __enable_irq();

    Servo_LeftArm((float)MuMu_InitialLeftAngle);
    Servo_RightArm(HighAngle);
}

void Servo_StartBothSwing(float HighAngle, float LowAngle,
                          uint16_t HalfPeriodMs, uint16_t TotalMs)
{
    if (HalfPeriodMs == 0)
    {
        HalfPeriodMs = 1;
    }

    __disable_irq();
    MuMu_MotionHighAngle = (uint16_t)HighAngle;
    MuMu_MotionLowAngle = (uint16_t)LowAngle;
    MuMu_MotionHalfPeriodMs = HalfPeriodMs;
    MuMu_MotionTotalMs = TotalMs;
    MuMu_ServoElapsedMs = 0;
    MuMu_ServoAction = SERVO_ACTION_BOTH_SWING;
    __enable_irq();

    Servo_LeftArm(HighAngle);
    Servo_RightArm(HighAngle);
}

void Servo_StartBothHold(float Angle, uint16_t TotalMs)
{
    __disable_irq();
    MuMu_MotionHighAngle = (uint16_t)Angle;
    MuMu_MotionTotalMs = TotalMs;
    MuMu_ServoElapsedMs = 0;
    MuMu_ServoAction = SERVO_ACTION_BOTH_HOLD;
    __enable_irq();

    Servo_LeftArm(Angle);
    Servo_RightArm(Angle);
}

void TIM3_IRQHandler(void)
{
    uint16_t Phase;
    uint16_t Period;
    uint16_t Angle;
    uint32_t Difference;

    if (TIM_GetITStatus(TIM3, TIM_IT_Update) == SET)
    {
        if (MuMu_ServoAction != SERVO_ACTION_NONE)
        {
            MuMu_ServoElapsedMs += 20;

            if (MuMu_ServoElapsedMs >= MuMu_MotionTotalMs)
            {
                MuMu_ServoAction = SERVO_ACTION_NONE;
                MuMu_ServoElapsedMs = 0;
                Servo_LeftArm((float)MuMu_InitialLeftAngle);
                Servo_RightArm((float)MuMu_InitialRightAngle);
            }
            else if (MuMu_ServoAction == SERVO_ACTION_BOTH_HOLD)
            {
                Servo_LeftArm((float)MuMu_MotionHighAngle);
                Servo_RightArm((float)MuMu_MotionHighAngle);
            }
            else
            {
                Period = MuMu_MotionHalfPeriodMs * 2;

                if (Period == 0)
                {
                    Period = 2;
                }

                Phase = MuMu_ServoElapsedMs % Period;
                Difference = MuMu_MotionHighAngle - MuMu_MotionLowAngle;

                if (Phase < MuMu_MotionHalfPeriodMs)
                {
                    Angle = MuMu_MotionHighAngle -
                            (uint16_t)(Difference * Phase /
                                       MuMu_MotionHalfPeriodMs);
                }
                else
                {
                    Angle = MuMu_MotionLowAngle +
                            (uint16_t)(Difference * (Phase -
                                                     MuMu_MotionHalfPeriodMs) /
                                       MuMu_MotionHalfPeriodMs);
                }

                if (MuMu_ServoAction == SERVO_ACTION_RIGHT_WAVE)
                {
                    Servo_LeftArm((float)MuMu_InitialLeftAngle);
                    Servo_RightArm((float)Angle);
                }
                else
                {
                    Servo_LeftArm((float)Angle);
                    Servo_RightArm((float)Angle);
                }
            }
        }

        TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    }
}
