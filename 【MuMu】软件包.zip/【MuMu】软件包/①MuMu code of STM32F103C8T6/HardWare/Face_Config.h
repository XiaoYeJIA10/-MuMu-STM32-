#ifndef __FACE_CONFIG_
#define __FACE_CONFIG_

#include <stdint.h>

void MuMuFace_Init(void);
void MuMuFace_ShowHappyOnce(void);
void MuMuFace_ShowSurprisedOnce(void);
void MuMuFace_ShowLookAroundOnce(void);
void MuMuFace_ShowBoredOnce(void);
void MuMuFace_ShowAngryOnce(void);
uint8_t MuMuFace_PlayRandomEmotion(void);

#endif
