#ifndef __BLUE_TOOTH_H
#define __BLUE_TOOTH_H

#include <stdint.h>

void BlueTooth_Init(void);
uint8_t BlueTooth_HasCommand(void);
uint8_t BlueTooth_GetCommand(void);

#endif
