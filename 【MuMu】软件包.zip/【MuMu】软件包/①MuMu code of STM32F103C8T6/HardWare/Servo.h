#ifndef __SERVO_H
#define __SERVO_H

#include <stdint.h>

void Servo_Init(void);
void Servo_SetInitialAngles(float LeftAngle, float RightAngle);
void Servo_LeftArm(float Angle);
void Servo_RightArm(float Angle);
void Servo_ReturnToInit(void);
void Servo_StartRightWave(float HighAngle, float LowAngle,
                          uint16_t HalfPeriodMs, uint16_t TotalMs);
void Servo_StartBothSwing(float HighAngle, float LowAngle,
                          uint16_t HalfPeriodMs, uint16_t TotalMs);
void Servo_StartBothHold(float Angle, uint16_t TotalMs);

#endif
