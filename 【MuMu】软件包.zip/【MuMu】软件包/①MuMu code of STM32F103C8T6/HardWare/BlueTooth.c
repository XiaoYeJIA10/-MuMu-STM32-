#include "stm32f10x.h"
#include "BlueTooth.h"

/*
 * 保存 USART1 或 USART3 最近收到的命令。
 * 中断中只记录命令，具体动作由主循环执行，避免在中断里进行长时间刷新。
 */
static volatile uint8_t MuMu_PendingCommand = 0;

/* 配置串口，两个串口可以使用不同波特率。 */
static void BlueTooth_ConfigUSART(USART_TypeDef *USARTx, uint32_t BaudRate)
{
    USART_InitTypeDef USART_InitStructure;

    USART_InitStructure.USART_BaudRate = BaudRate;
    USART_InitStructure.USART_WordLength = USART_WordLength_8b;
    USART_InitStructure.USART_StopBits = USART_StopBits_1;
    USART_InitStructure.USART_Parity = USART_Parity_No;
    USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
    USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;

    USART_Init(USARTx, &USART_InitStructure);
    USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
    USART_Cmd(USARTx, ENABLE);
}

void BlueTooth_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |
                           RCC_APB2Periph_GPIOB |
                           RCC_APB2Periph_USART1, ENABLE);
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);

    /* USART1：PA9 为 TX，PA10 为 RX。 */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    /* USART3：PB10 为 TX，PB11 为 RX。 */
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_11;
    GPIO_Init(GPIOB, &GPIO_InitStructure);

    /* USART1 接语音模块，使用 9600 波特率。 */
    BlueTooth_ConfigUSART(USART1, 9600);

    /* USART3 接蓝牙模块，使用 115200 波特率。 */
    BlueTooth_ConfigUSART(USART3, 115200);

    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);

    NVIC_InitStructure.NVIC_IRQChannel = USART1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);

    NVIC_InitStructure.NVIC_IRQChannel = USART3_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_Init(&NVIC_InitStructure);
}

uint8_t BlueTooth_HasCommand(void)
{
    return (MuMu_PendingCommand != 0);
}

uint8_t BlueTooth_GetCommand(void)
{
    uint8_t Command;

    Command = MuMu_PendingCommand;
    MuMu_PendingCommand = 0;

    return Command;
}

static void BlueTooth_ProcessCommand(uint8_t Command)
{
    /* 当前处理 0x31 到 0x34 四条 MuMu 指令。 */
    if (Command >= 0x31 && Command <= 0x34)
    {
        MuMu_PendingCommand = Command;
    }
}

void USART1_IRQHandler(void)
{
    uint8_t Command;

    if (USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        Command = (uint8_t)USART_ReceiveData(USART1);
        BlueTooth_ProcessCommand(Command);
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
}

void USART3_IRQHandler(void)
{
    uint8_t Command;

    if (USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
    {
        Command = (uint8_t)USART_ReceiveData(USART3);
        BlueTooth_ProcessCommand(Command);
        USART_ClearITPendingBit(USART3, USART_IT_RXNE);
    }
}
