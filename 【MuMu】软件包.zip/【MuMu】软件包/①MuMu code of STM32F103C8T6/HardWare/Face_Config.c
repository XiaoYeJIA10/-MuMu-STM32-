#include "stm32f10x.h"
#include "OLED.h"
#include "BlueTooth.h"
#include "Delay.h"
#include "Face_Config.h"

/* 眼睛尺寸和位置定义。 */
#define MUMU_EYE_WIDTH              26
#define MUMU_EYE_HEIGHT             30
#define MUMU_EYE_CORNER_RADIUS       4
#define MUMU_EYE_LEFT_X             34
#define MUMU_EYE_RIGHT_X            94
#define MUMU_EYE_CENTER_Y           32

/* 伪随机数状态和上一次播放的表情编号。 */
static uint32_t MuMu_RandomState = 0x6D2B79F5u;
static uint8_t MuMu_LastEmotion = 0xFF;

static void MuMu_DrawRoundedSquare(int16_t X, int16_t Y,
                                   uint8_t Width, uint8_t Height,
                                   uint8_t Radius)
{
    uint8_t MiddleWidth;
    uint8_t MiddleHeight;

    if (Width == 0 || Height == 0)
    {
        return;
    }

    if (Radius > Width / 2)
    {
        Radius = Width / 2;
    }

    if (Radius > Height / 2)
    {
        Radius = Height / 2;
    }

    MiddleWidth = Width - Radius * 2;
    MiddleHeight = Height - Radius * 2;

    if (MiddleWidth > 0)
    {
        OLED_DrawRectangle(X + Radius, Y,
                           MiddleWidth, Height, OLED_FILLED);
    }

    if (MiddleHeight > 0)
    {
        OLED_DrawRectangle(X, Y + Radius,
                           Width, MiddleHeight, OLED_FILLED);
    }

    if (Radius > 0)
    {
        OLED_DrawCircle(X + Radius, Y + Radius,
                        Radius, OLED_FILLED);
        OLED_DrawCircle(X + Width - Radius - 1, Y + Radius,
                        Radius, OLED_FILLED);
        OLED_DrawCircle(X + Radius, Y + Height - Radius - 1,
                        Radius, OLED_FILLED);
        OLED_DrawCircle(X + Width - Radius - 1,
                        Y + Height - Radius - 1,
                        Radius, OLED_FILLED);
    }
}

static void MuMu_DrawEyePair(int16_t EyeOffsetX,
                             int16_t EyeOffsetY,
                             uint8_t EyeWidth,
                             uint8_t EyeHeight)
{
    int16_t EyeTopY;
    int16_t LeftEyeX;
    int16_t RightEyeX;

    EyeTopY = MUMU_EYE_CENTER_Y - EyeHeight / 2 + EyeOffsetY;
    LeftEyeX = MUMU_EYE_LEFT_X - EyeWidth / 2 + EyeOffsetX;
    RightEyeX = MUMU_EYE_RIGHT_X - EyeWidth / 2 + EyeOffsetX;

    MuMu_DrawRoundedSquare(LeftEyeX, EyeTopY,
                           EyeWidth, EyeHeight,
                           MUMU_EYE_CORNER_RADIUS);

    MuMu_DrawRoundedSquare(RightEyeX, EyeTopY,
                           EyeWidth, EyeHeight,
                           MUMU_EYE_CORNER_RADIUS);
}

static int16_t MuMu_Min16(int16_t A, int16_t B)
{
    return (A < B) ? A : B;
}

static int16_t MuMu_Max16(int16_t A, int16_t B)
{
    return (A > B) ? A : B;
}

static void MuMu_UpdateMergedArea(int16_t X0, int16_t Y0,
                                  int16_t X1, int16_t Y1,
                                  int16_t X2, int16_t Y2,
                                  int16_t X3, int16_t Y3)
{
    int16_t Left;
    int16_t Top;
    int16_t Right;
    int16_t Bottom;
    uint8_t Width;
    uint8_t Height;

    Left = MuMu_Min16(MuMu_Min16(X0, X1), MuMu_Min16(X2, X3)) - 2;
    Top = MuMu_Min16(MuMu_Min16(Y0, Y1), MuMu_Min16(Y2, Y3)) - 2;
    Right = MuMu_Max16(MuMu_Max16(X0, X1), MuMu_Max16(X2, X3)) + 2;
    Bottom = MuMu_Max16(MuMu_Max16(Y0, Y1), MuMu_Max16(Y2, Y3)) + 2;

    if (Left < 0)
    {
        Left = 0;
    }

    if (Top < 0)
    {
        Top = 0;
    }

    if (Right > 127)
    {
        Right = 127;
    }

    if (Bottom > 63)
    {
        Bottom = 63;
    }

    if (Left <= Right && Top <= Bottom)
    {
        Width = Right - Left + 1;
        Height = Bottom - Top + 1;
        OLED_UpdateArea(Left, Top, Width, Height);
    }
}

static void MuMu_ShowEyeFrame(int16_t EyeOffsetX,
                              int16_t EyeOffsetY,
                              uint8_t EyeWidth,
                              uint8_t EyeHeight)
{
    static int16_t PreviousLeftX = 0;
    static int16_t PreviousLeftY = 0;
    static int16_t PreviousRightX = 0;
    static int16_t PreviousRightY = 0;
    static uint8_t PreviousEyeWidth = MUMU_EYE_WIDTH;
    static uint8_t PreviousEyeHeight = MUMU_EYE_HEIGHT;
    static uint8_t HasPreviousFrame = 0;

    int16_t CurrentLeftX;
    int16_t CurrentLeftY;
    int16_t CurrentRightX;
    int16_t CurrentRightY;

    CurrentLeftX = MUMU_EYE_LEFT_X - EyeWidth / 2 + EyeOffsetX;
    CurrentLeftY = MUMU_EYE_CENTER_Y - EyeHeight / 2 + EyeOffsetY;
    CurrentRightX = MUMU_EYE_RIGHT_X - EyeWidth / 2 + EyeOffsetX;
    CurrentRightY = CurrentLeftY;

    OLED_Clear();
    MuMu_DrawEyePair(EyeOffsetX, EyeOffsetY, EyeWidth, EyeHeight);

    if (HasPreviousFrame == 0)
    {
        PreviousLeftX = CurrentLeftX;
        PreviousLeftY = CurrentLeftY;
        PreviousRightX = CurrentRightX;
        PreviousRightY = CurrentRightY;
        PreviousEyeWidth = EyeWidth;
        PreviousEyeHeight = EyeHeight;
        HasPreviousFrame = 1;
    }

    MuMu_UpdateMergedArea(PreviousLeftX, PreviousLeftY,
                          PreviousLeftX + PreviousEyeWidth - 1,
                          PreviousLeftY + PreviousEyeHeight - 1,
                          CurrentLeftX, CurrentLeftY,
                          CurrentLeftX + EyeWidth - 1,
                          CurrentLeftY + EyeHeight - 1);

    MuMu_UpdateMergedArea(PreviousRightX, PreviousRightY,
                          PreviousRightX + PreviousEyeWidth - 1,
                          PreviousRightY + PreviousEyeHeight - 1,
                          CurrentRightX, CurrentRightY,
                          CurrentRightX + EyeWidth - 1,
                          CurrentRightY + EyeHeight - 1);

    PreviousLeftX = CurrentLeftX;
    PreviousLeftY = CurrentLeftY;
    PreviousRightX = CurrentRightX;
    PreviousRightY = CurrentRightY;
    PreviousEyeWidth = EyeWidth;
    PreviousEyeHeight = EyeHeight;
}

static uint32_t MuMu_GetRandomValue(void)
{
    MuMu_RandomState ^= MuMu_RandomState << 13;
    MuMu_RandomState ^= MuMu_RandomState >> 17;
    MuMu_RandomState ^= MuMu_RandomState << 5;

    return MuMu_RandomState;
}

static uint8_t MuMu_GetRandomEmotion(void)
{
    uint8_t NextEmotion;

    do
    {
        NextEmotion = (uint8_t)(MuMu_GetRandomValue() % 5u);
    }
    while (NextEmotion == MuMu_LastEmotion);

    MuMu_LastEmotion = NextEmotion;

    return NextEmotion;
}

/* 1. 开心：双眼在一个周期内向上跳动两次。 */
static void MuMu_ShowHappyAnimation(void)
{
    static const int8_t EyeY[] = {0, -2, -5, -3, 0, -2, -5, -3, 0};
    uint8_t i;

    for (i = 0; i < sizeof(EyeY) / sizeof(EyeY[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(0, EyeY[i],
                          MUMU_EYE_WIDTH, MUMU_EYE_HEIGHT);
        Delay_ms(1000 / (sizeof(EyeY) / sizeof(EyeY[0])));
    }
}

/* 眨眼过渡：正常 -> 闭眼 -> 正常。 */
static void MuMu_PlayBlinkAnimation(void)
{
    static const uint8_t BlinkHeight[] =
    {
        30, 24, 18, 12, 6, 2, 6, 12, 18, 24, 30
    };
    uint8_t i;

    for (i = 0; i < sizeof(BlinkHeight) / sizeof(BlinkHeight[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(0, 0, MUMU_EYE_WIDTH, BlinkHeight[i]);
        Delay_ms(35);
    }
}

/* 2. 左右张望：双眼先向左，再向右，最后回到中间。 */
static void MuMu_ShowLookAroundAnimation(void)
{
    static const int16_t LookOffset[] =
    {
        0, -3, -6, -9, -12, -12, -9, -6, -3,
        0, 3, 6, 9, 12, 12, 9, 6, 3, 0
    };
    uint8_t i;

    for (i = 0; i < sizeof(LookOffset) / sizeof(LookOffset[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(LookOffset[i], 0,
                          MUMU_EYE_WIDTH, MUMU_EYE_HEIGHT);
        Delay_ms(1000 / (sizeof(LookOffset) / sizeof(LookOffset[0])));
    }
}

/* 3. 惊讶：眼睛先缩小，再放大，最后恢复正常尺寸。 */
static void MuMu_ShowSurprisedAnimation(void)
{
    static const uint8_t EyeWidth[] =
    {
        26, 22, 18, 14, 10, 12, 16, 22, 28, 32, 34, 34, 30, 26
    };
    static const uint8_t EyeHeight[] =
    {
        30, 26, 22, 17, 12, 14, 18, 24, 32, 38, 40, 40, 34, 30
    };
    uint8_t i;

    for (i = 0; i < sizeof(EyeWidth) / sizeof(EyeWidth[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(0, 0, EyeWidth[i], EyeHeight[i]);
        Delay_ms(1000 / (sizeof(EyeWidth) / sizeof(EyeWidth[0])));
    }
}

/* 4. 无聊：双眼沿半径 3 像素的小圆顺时针移动一圈。 */
static void MuMu_ShowBoredAnimation(void)
{
    static const int8_t OffsetX[] =
    {
        0, 1, 2, 3, 3, 3, 2, 1,
        0, -1, -2, -3, -3, -3, -2, -1
    };
    static const int8_t OffsetY[] =
    {
        -3, -3, -2, -1, 0, 1, 2, 3,
        3, 3, 2, 1, 0, -1, -2, -3
    };
    uint8_t i;

    for (i = 0; i < sizeof(OffsetX) / sizeof(OffsetX[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(OffsetX[i], OffsetY[i],
                          MUMU_EYE_WIDTH, MUMU_EYE_HEIGHT);
        Delay_ms(1000 / (sizeof(OffsetX) / sizeof(OffsetX[0])));
    }

    if (!BlueTooth_HasCommand())
    {
        MuMu_ShowEyeFrame(0, 0, MUMU_EYE_WIDTH, MUMU_EYE_HEIGHT);
    }
}

/* 5. 生气：双眼在一个周期内向下跳动两次。 */
static void MuMu_ShowAngryAnimation(void)
{
    static const int8_t EyeY[] = {0, 2, 5, 3, 0, 2, 5, 3, 0};
    uint8_t i;

    for (i = 0; i < sizeof(EyeY) / sizeof(EyeY[0]); i++)
    {
        if (BlueTooth_HasCommand())
        {
            return;
        }

        MuMu_ShowEyeFrame(0, EyeY[i],
                          MUMU_EYE_WIDTH, MUMU_EYE_HEIGHT);
        Delay_ms(1000 / (sizeof(EyeY) / sizeof(EyeY[0])));
    }
}

static void MuMu_PlayEmotionOnce(uint8_t Emotion)
{
    switch (Emotion)
    {
        case 0:
            MuMu_ShowHappyAnimation();
            break;

        case 1:
            MuMu_ShowLookAroundAnimation();
            break;

        case 2:
            MuMu_ShowSurprisedAnimation();
            break;

        case 3:
            MuMu_ShowBoredAnimation();
            break;

        case 4:
            MuMu_ShowAngryAnimation();
            break;

        default:
            break;
    }
}

void MuMuFace_Init(void)
{
    MuMu_RandomState ^= TIM2->CNT;

    if (MuMu_RandomState == 0)
    {
        MuMu_RandomState = 0x6D2B79F5u;
    }

    MuMu_LastEmotion = 0xFF;

    OLED_Clear();
    OLED_Update();
}

/*
 * 随机播放一种表情两遍，然后眨眼。
 * 这是上电后的默认空闲行为。
 */
uint8_t MuMuFace_PlayRandomEmotion(void)
{
    uint8_t Emotion;

    Emotion = MuMu_GetRandomEmotion();

    MuMu_PlayEmotionOnce(Emotion);

    if (BlueTooth_HasCommand())
    {
        return 0;
    }

    MuMu_PlayEmotionOnce(Emotion);

    if (BlueTooth_HasCommand())
    {
        return 0;
    }

    MuMu_PlayBlinkAnimation();

    if (BlueTooth_HasCommand())
    {
        return 0;
    }

    Delay_ms(80);

    return 1;
}

/* 连续播放开心动画两遍，总时长约 2 秒。 */
void MuMuFace_ShowHappyOnce(void)
{
    MuMu_ShowHappyAnimation();

    if (BlueTooth_HasCommand())
    {
        return;
    }

    MuMu_ShowHappyAnimation();
}

/* 连续播放惊讶动画两遍，总时长约 2 秒。 */
void MuMuFace_ShowSurprisedOnce(void)
{
    MuMu_ShowSurprisedAnimation();

    if (BlueTooth_HasCommand())
    {
        return;
    }

    MuMu_ShowSurprisedAnimation();
}

/* 连续播放左右张望动画两遍，总时长约 2 秒。 */
void MuMuFace_ShowLookAroundOnce(void)
{
    MuMu_ShowLookAroundAnimation();

    if (BlueTooth_HasCommand())
    {
        return;
    }

    MuMu_ShowLookAroundAnimation();
}

/* 连续播放无聊动画两遍，总时长约 2 秒。 */
void MuMuFace_ShowBoredOnce(void)
{
    MuMu_ShowBoredAnimation();

    if (BlueTooth_HasCommand())
    {
        return;
    }

    MuMu_ShowBoredAnimation();
}

/* 连续播放生气动画两遍，总时长约 2 秒。 */
void MuMuFace_ShowAngryOnce(void)
{
    MuMu_ShowAngryAnimation();

    if (BlueTooth_HasCommand())
    {
        return;
    }

    MuMu_ShowAngryAnimation();
}
